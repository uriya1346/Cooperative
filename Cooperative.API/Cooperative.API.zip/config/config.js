exports.secret = {
    userDb:"uria1346",
    passDb:"A12s34D56",
    jwtSecret:"UriyaPass"
  }
